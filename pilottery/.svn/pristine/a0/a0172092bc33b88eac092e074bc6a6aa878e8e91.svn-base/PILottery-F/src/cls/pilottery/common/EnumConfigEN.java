package cls.pilottery.common;

import java.util.HashMap;
import java.util.Map;

/**
 * 系统枚举
 **/
public class EnumConfigEN {

	public static Map<Integer,String> userStatus = new HashMap<Integer,String>();
	public static Map<Integer,String> areaStatus = new HashMap<Integer,String>();
	public static Map<Integer,String> areaType = new HashMap<Integer,String>();
	public static Map<Integer,String> orgType = new HashMap<Integer,String>();
	public static Map<Integer,String> purchaseOrderStatus = new HashMap<Integer,String>();
	public static Map<Integer,String> deliveryOrderStatus = new HashMap<Integer,String>();
	public static Map<Integer,String> stockTransferStatus = new HashMap<Integer,String>();
	public static Map<Integer,String> goodsReceiptStatus= new HashMap<Integer,String>();
	public static Map<Integer,String> goodsReceiptType=new HashMap<Integer,String>();
	public static Map<Integer,String> agencyType=new HashMap<Integer,String>();
	public static Map<Integer,String> batchStatus=new HashMap<Integer,String>();
	public static Map<Integer,String> goodsIssuesType=new HashMap<Integer,String>();
	public static Map<Integer,String>  checkPointStatus=new HashMap<Integer,String>();
	public static Map<Integer,String>  checkResult=new HashMap<Integer,String>();
	public static Map<Integer,String>  transFlowType=new HashMap<Integer,String>();
	public static Map<Integer,String>  returnDeliveryStatus=new HashMap<Integer,String>();
	public static Map<Integer,String>  sex=new HashMap<Integer,String>();
	public static Map<Integer,String>  cashWithdrawnStatus=new HashMap<Integer,String>();
	public static Map<Integer,String>  outOrInputStatus=new HashMap<Integer,String>();
	public static Map<Integer,String>  ticketPayoutStatus=new HashMap<Integer,String>();
	public static Map<Integer,String>  outletStatus=new HashMap<Integer,String>();
	public static Map<Integer,String>  pecification=new HashMap<Integer,String>();
	public static Map<Integer,String> approveAccountType=new HashMap<Integer,String>();
	public static Map<Integer,String> brokenReason=new HashMap<Integer,String>();
	public static Map<Integer,String> mmInventoryDaliyType=new HashMap<Integer,String>();
	public static Map<Integer,String> mmCapitalDaliyType=new HashMap<Integer,String>();
	public static Map<Integer,String> mmInventoryCheckStatus=new HashMap<Integer,String>();
	public static Map<Integer,String> mmTransRecordType=new HashMap<Integer,String>();
	public static Map<Integer,String> mmPayoutRecordStatus=new HashMap<Integer,String>();
	public static Map<Integer,String> oldTicket=new HashMap<Integer,String>();
	
}
