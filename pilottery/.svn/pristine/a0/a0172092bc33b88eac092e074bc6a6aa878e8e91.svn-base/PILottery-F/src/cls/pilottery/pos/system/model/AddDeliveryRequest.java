package cls.pilottery.pos.system.model;

import java.io.Serializable;
import java.util.List;

public class AddDeliveryRequest implements Serializable {
	private static final long serialVersionUID = 6513748637347581802L;
	private List<String> orderList;
	private List<AddDeliveryDetail> plansList;
	
	public List<String> getOrderList() {
		return orderList;
	}

	public void setOrderList(List<String> orderList) {
		this.orderList = orderList;
	}

	public List<AddDeliveryDetail> getPlansList() {
		return plansList;
	}

	public void setPlansList(List<AddDeliveryDetail> plansList) {
		this.plansList = plansList;
	}
}
