package cls.pilottery.web.outlet.form;

import java.io.Serializable;

public class ResetPassowrd implements Serializable {

	private static final long serialVersionUID = 1L;

	private String outletCode;

	private String password;

	public String getOutletCode() {

		return outletCode;
	}

	public ResetPassowrd() {

	}

	public void setOutletCode(String outletCode) {

		this.outletCode = outletCode;
	}

	public String getPassword() {

		return password;
	}

	public void setPassword(String password) {

		this.password = password;
	}
}
