package cls.pilottery.pos.system.model;

import java.io.Serializable;

public class NewOrderResponse implements Serializable {
	private static final long serialVersionUID = -7782700995376354218L;

}
