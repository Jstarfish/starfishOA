package cls.pilottery.pos.system.model.mm;

import java.util.List;

public class MMInventoryCheck020507Res implements java.io.Serializable{
	private static final long serialVersionUID = 5975477136380894209L;
	private int inventoryTickets;
	private int checkTickets;
	private int diffTickets;
	private List<MMInventoryCheckTag020507Res> recordList;
	public int getInventoryTickets() {
		return inventoryTickets;
	}
	public void setInventoryTickets(int inventoryTickets) {
		this.inventoryTickets = inventoryTickets;
	}
	public int getCheckTickets() {
		return checkTickets;
	}
	public void setCheckTickets(int checkTickets) {
		this.checkTickets = checkTickets;
	}
	public int getDiffTickets() {
		return diffTickets;
	}
	public void setDiffTickets(int diffTickets) {
		this.diffTickets = diffTickets;
	}
	public List<MMInventoryCheckTag020507Res> getRecordList() {
		return recordList;
	}
	public void setRecordList(List<MMInventoryCheckTag020507Res> recordList) {
		this.recordList = recordList;
	}
}
