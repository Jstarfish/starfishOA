package cls.pilottery.web.goodsreceipts.model;

public class GoodsReceiptTrans {
	private String stbNo;
    private String receiveUnit;
    private String sendUnit;
	public String getStbNo() {
		return stbNo;
	}
	public void setStbNo(String stbNo) {
		this.stbNo = stbNo;
	}
	public String getReceiveUnit() {
		return receiveUnit;
	}
	public void setReceiveUnit(String receiveUnit) {
		this.receiveUnit = receiveUnit;
	}
	public String getSendUnit() {
		return sendUnit;
	}
	public void setSendUnit(String sendUnit) {
		this.sendUnit = sendUnit;
	}
    
}
