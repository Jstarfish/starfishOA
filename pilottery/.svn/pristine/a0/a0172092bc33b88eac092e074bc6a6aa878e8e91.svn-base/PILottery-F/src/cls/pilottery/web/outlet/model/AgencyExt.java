package cls.pilottery.web.outlet.model;

public class AgencyExt {
	private String agencyCode;// 站点编号

	private String personalId;// 证件号码

	private String contractNo;// 合同编号

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getPersonalId() {
		return personalId;
	}

	public void setPersonalId(String personalId) {
		this.personalId = personalId;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

	public AgencyExt() {
	}
}
