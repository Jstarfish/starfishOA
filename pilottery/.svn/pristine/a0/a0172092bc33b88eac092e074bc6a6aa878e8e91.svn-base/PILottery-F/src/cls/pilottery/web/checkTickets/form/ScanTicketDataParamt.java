package cls.pilottery.web.checkTickets.form;

public class ScanTicketDataParamt {
 private String planCode;
 private String batchNo;
 private String packageNo;
 private int ticketNo;
 private String securityCode;
public String getPlanCode() {
	return planCode;
}
public void setPlanCode(String planCode) {
	this.planCode = planCode;
}
public String getBatchNo() {
	return batchNo;
}
public void setBatchNo(String batchNo) {
	this.batchNo = batchNo;
}
public String getPackageNo() {
	return packageNo;
}
public void setPackageNo(String packageNo) {
	this.packageNo = packageNo;
}
public int getTicketNo() {
	return ticketNo;
}
public void setTicketNo(int ticketNo) {
	this.ticketNo = ticketNo;
}
public String getSecurityCode() {
	return securityCode;
}
public void setSecurityCode(String securityCode) {
	this.securityCode = securityCode;
}
 
}
