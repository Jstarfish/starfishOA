package cls.pilottery.pos.system.model;

/*
 * 站点入库信息
 */
public class OutletGoodInfo {

	private	String goodsTag;
	private long tickets;
	public String getGoodsTag() {
		return goodsTag;
	}
	public void setGoodsTag(String goodsTag) {
		this.goodsTag = goodsTag;
	}
	public long getTickets() {
		return tickets;
	}
	public void setTickets(long tickets) {
		this.tickets = tickets;
	}
	
}
