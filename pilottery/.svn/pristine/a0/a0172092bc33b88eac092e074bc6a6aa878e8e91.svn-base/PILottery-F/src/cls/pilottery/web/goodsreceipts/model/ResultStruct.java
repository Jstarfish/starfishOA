package cls.pilottery.web.goodsreceipts.model;

public class ResultStruct {
 private String planCode;
 private String planName;
 private String errcode;
 private String errmsg;
public String getPlanCode() {
	return planCode;
}
public void setPlanCode(String planCode) {
	this.planCode = planCode;
}
public String getPlanName() {
	return planName;
}
public void setPlanName(String planName) {
	this.planName = planName;
}
public String getErrcode() {
	return errcode;
}
public void setErrcode(String errcode) {
	this.errcode = errcode;
}
public String getErrmsg() {
	return errmsg;
}
public void setErrmsg(String errmsg) {
	this.errmsg = errmsg;
}
 
}
