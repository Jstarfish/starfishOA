package cls.pilottery.web.outlet.form;

import java.io.Serializable;

import cls.pilottery.common.model.BaseEntity;

public class ListOutletForm extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	private String outletCode;

	private String outletName;

	private String institutionName;

	private String area;

	private String contractPerson;

	private String contractPhone;

	private String insCode;

	private int status;

	private String statusValue;

	
	public String getOutletCode() {
	
		return outletCode;
	}

	
	public void setOutletCode(String outletCode) {
	
		this.outletCode = outletCode;
	}

	
	public String getOutletName() {
	
		return outletName;
	}

	
	public void setOutletName(String outletName) {
	
		this.outletName = outletName;
	}

	
	public String getInstitutionName() {
	
		return institutionName;
	}

	
	public void setInstitutionName(String institutionName) {
	
		this.institutionName = institutionName;
	}

	
	public String getArea() {
	
		return area;
	}

	
	public void setArea(String area) {
	
		this.area = area;
	}

	
	public String getContractPerson() {
	
		return contractPerson;
	}

	
	public void setContractPerson(String contractPerson) {
	
		this.contractPerson = contractPerson;
	}

	
	public String getContractPhone() {
	
		return contractPhone;
	}

	
	public void setContractPhone(String contractPhone) {
	
		this.contractPhone = contractPhone;
	}

	
	public String getInsCode() {
	
		return insCode;
	}

	
	public void setInsCode(String insCode) {
	
		this.insCode = insCode;
	}

	
	public int getStatus() {
	
		return status;
	}

	
	public void setStatus(int status) {
	
		this.status = status;
	}

	
	public String getStatusValue() {
	
		return statusValue;
	}

	
	public void setStatusValue(String statusValue) {
	
		this.statusValue = statusValue;
	}

	
}
