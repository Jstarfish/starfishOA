package cls.pilottery.web.marketManager.service;

import cls.pilottery.web.marketManager.entity.AccountBalance;


public interface AccountBalanceService {
	
		public AccountBalance getMarketAccountInfo(Long maketAdmin);
}
