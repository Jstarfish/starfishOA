package cls.pilottery.web.capital.model;

import java.io.Serializable;

/**
 * 站点方案佣金实体
 * 
 */
public class OutletCommRate implements Serializable {

	private static final long serialVersionUID = 395819007857426192L;
	private String agencyCode;
	private String planCode;
	private Long saleComm;
	private Long payComm;

	public String getAgencyCode() {
		return agencyCode;
	}

	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	public Long getSaleComm() {
		return saleComm;
	}

	public void setSaleComm(Long saleComm) {
		this.saleComm = saleComm;
	}

	public Long getPayComm() {
		return payComm;
	}

	public void setPayComm(Long payComm) {
		this.payComm = payComm;
	}

}
