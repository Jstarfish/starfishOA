package cls.pilottery.web.inventory.model;

public class WhInfoVo {
	private String whcode;
	private String whname;

	public String getWhcode() {
		return whcode;
	}

	public void setWhcode(String whcode) {
		this.whcode = whcode;
	}

	public String getWhname() {
		return whname;
	}

	public void setWhname(String whname) {
		this.whname = whname;
	}

}
