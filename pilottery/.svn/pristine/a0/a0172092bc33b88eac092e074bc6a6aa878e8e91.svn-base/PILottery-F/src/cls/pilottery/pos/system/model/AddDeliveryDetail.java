package cls.pilottery.pos.system.model;

import java.io.Serializable;

public class AddDeliveryDetail implements Serializable {

	private static final long serialVersionUID = 4835396516880056536L;
	private String planCode;
	private int tickets;

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	public int getTickets() {
		return tickets;
	}

	public void setTickets(int tickets) {
		this.tickets = tickets;
	}

}
