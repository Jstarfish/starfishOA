package cls.pilottery.common.constants;

/**
 * 项目名：泰山无纸化平台 
 * 文件名：SysConstants.java
 * 类描述：定义系统的常量
 * 创建人：huangchengyuan@chinalotsynergy.com
 * 日期：</b>2015-8-21-上午09:53:44
 * 版本信息：v1.0.0
 * Copyright (c) 2015华彩控股有限公司-版权所有
 */
public class SysConstants {
	
	//当前登陆用户
	public static final String CURR_LOGIN_USER_SESSION="current_user";
	
	//用于语言切换页面--英文页面后缀
	public static final String PAGE_EN_SUFFIX ="";
	
	//用于语言切换页面--中文页面后缀
	public static final String PAGE_ZH_SUFFIX ="_zh";
	
	public static final String INIT_LOGIN_PASSWORD = "111111";
	
	public static final String INIT_TRANS_PASSWORD = "111111";

}
