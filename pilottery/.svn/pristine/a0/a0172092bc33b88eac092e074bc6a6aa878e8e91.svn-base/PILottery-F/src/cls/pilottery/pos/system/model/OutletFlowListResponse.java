package cls.pilottery.pos.system.model;

import java.util.List;

/*
 * 站点查询列表返回信息
 */
public class OutletFlowListResponse {

	private String outletCode;
	private long balance=0;
	private long credit=0;
	private String follow;
	
	private List<OutletFundFlow> recordList = null;

	public String getOutletCode() {
		return outletCode;
	}

	public void setOutletCode(String outletCode) {
		this.outletCode = outletCode;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public long getCredit() {
		return credit;
	}

	public void setCredit(long credit) {
		this.credit = credit;
	}

	public String getFollow() {
		return follow;
	}

	public void setFollow(String follow) {
		this.follow = follow;
	}

	public List<OutletFundFlow> getRecordList() {
		return recordList;
	}

	public void setRecordList(List<OutletFundFlow> recordList) {
		this.recordList = recordList;
	}

	
}
