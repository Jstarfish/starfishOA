package cls.pilottery.pos.system.model;

import java.io.Serializable;

public class NewOrderRequest implements Serializable {
	private static final long serialVersionUID = 5133023162597832099L;

}
