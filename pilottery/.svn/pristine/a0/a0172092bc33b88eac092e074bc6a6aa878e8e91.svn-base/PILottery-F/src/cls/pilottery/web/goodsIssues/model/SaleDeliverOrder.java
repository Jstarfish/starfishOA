package cls.pilottery.web.goodsIssues.model;

public class SaleDeliverOrder {
 private String doNo;
 private String applyAdminName;

public String getDoNo() {
	return doNo;
}

public void setDoNo(String doNo) {
	this.doNo = doNo;
}

public String getApplyAdminName() {
	return applyAdminName;
}

public void setApplyAdminName(String applyAdminName) {
	this.applyAdminName = applyAdminName;
}
 
}
