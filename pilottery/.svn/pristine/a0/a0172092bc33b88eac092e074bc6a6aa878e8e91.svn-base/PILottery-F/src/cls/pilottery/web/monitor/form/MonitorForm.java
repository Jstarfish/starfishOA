package cls.pilottery.web.monitor.form;

import cls.pilottery.common.model.BaseEntity;

public class MonitorForm extends BaseEntity {
	private static final long serialVersionUID = -3782677293774944953L;
	private String planCode;
	private String orgCode;
	private String queryDate;
	private String areaCode;
	public String getQueryDate() {
		return queryDate;
	}
	public void setQueryDate(String queryDate) {
		this.queryDate = queryDate;
	}
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
}
