package cls.pilottery.web.area.model;

import java.util.ArrayList;
import java.util.List;

public class GameAuthArray {
	 private List<GameAuth> guth = new ArrayList<GameAuth>();

	public List<GameAuth> getGuth() {
		return guth;
	}

	public void setGuth(List<GameAuth> guth) {
		this.guth = guth;
	} 
	 
}
