package cls.pilottery.common.service;

/**
 * Service基类接口
 * @author Woo
 */
public interface BaseService {
	
}
