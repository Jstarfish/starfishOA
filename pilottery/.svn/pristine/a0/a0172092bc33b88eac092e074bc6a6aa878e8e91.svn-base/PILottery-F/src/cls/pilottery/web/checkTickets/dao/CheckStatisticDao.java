package cls.pilottery.web.checkTickets.dao;

import java.util.List;

import cls.pilottery.web.checkTickets.form.CheckStatisticForm;
import cls.pilottery.web.checkTickets.model.CheckStatisticVo;
import cls.pilottery.web.checkTickets.model.CheckStatisticsInfo;

public interface CheckStatisticDao {
   
	List<CheckStatisticVo> getCheckStatisticList(CheckStatisticForm checkStatisticForm);
   
    List<CheckStatisticVo> getRefuseRecordsListInfo(CheckStatisticForm checkStatisticForm);

	List<CheckStatisticsInfo> getStatisticInfo(String flowNo);
}
