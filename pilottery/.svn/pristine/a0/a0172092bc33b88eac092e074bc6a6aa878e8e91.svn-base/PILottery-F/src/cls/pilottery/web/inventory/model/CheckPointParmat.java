package cls.pilottery.web.inventory.model;

import java.util.ArrayList;
import java.util.List;

import cls.pilottery.web.goodsreceipts.model.GameBatchParamt;

public class CheckPointParmat {
	private String id;
	private String cpName;// 盘点名称
	private Long cpAdmin;// 盘点人
	private String planCode;// 方案
	private String batchNo;// 批次编码
	private String houseCode;// 仓库编码
	private String ccheckcode;
	private int cerrorcode;
	private String cerrormesg;
	private String cpNo;
	private List<GameBatchParamt> para= new ArrayList<GameBatchParamt>();
	public String getCpName() {
		return cpName;
	}

	public void setCpName(String cpName) {
		this.cpName = cpName;
	}

	public Long getCpAdmin() {
		return cpAdmin;
	}

	public void setCpAdmin(Long cpAdmin) {
		this.cpAdmin = cpAdmin;
	}

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getHouseCode() {
		return houseCode;
	}

	public void setHouseCode(String houseCode) {
		this.houseCode = houseCode;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getCerrorcode() {
		return cerrorcode;
	}

	public void setCerrorcode(int cerrorcode) {
		this.cerrorcode = cerrorcode;
	}

	public String getCerrormesg() {
		return cerrormesg;
	}

	public void setCerrormesg(String cerrormesg) {
		this.cerrormesg = cerrormesg;
	}

	public String getCcheckcode() {
		return ccheckcode;
	}

	public void setCcheckcode(String ccheckcode) {
		this.ccheckcode = ccheckcode;
	}

	public String getCpNo() {
		return cpNo;
	}

	public void setCpNo(String cpNo) {
		this.cpNo = cpNo;
	}

	public List<GameBatchParamt> getPara() {
		return para;
	}

	public void setPara(List<GameBatchParamt> para) {
		this.para = para;
	}

}
