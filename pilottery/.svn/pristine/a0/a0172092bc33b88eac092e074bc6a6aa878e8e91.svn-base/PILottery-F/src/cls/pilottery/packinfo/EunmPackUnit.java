package cls.pilottery.packinfo;

public enum EunmPackUnit {

	Trunck,//箱子
	Box,   //盒子
	pkg,   //本子
	ticket //票，仅用于保安全显示
}
