package cls.pilottery.pos.system.model.mm;

import java.io.Serializable;

public class MMInventoryCheckTag020507Req implements Serializable {
	private static final long serialVersionUID = -506098824924436973L;
	private String tagNo;

	public String getTagNo() {
		return tagNo;
	}

	public void setTagNo(String tagNo) {
		this.tagNo = tagNo;
	}
}
