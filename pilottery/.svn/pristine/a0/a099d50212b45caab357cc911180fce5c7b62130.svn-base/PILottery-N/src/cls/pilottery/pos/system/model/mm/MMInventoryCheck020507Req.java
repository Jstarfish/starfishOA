package cls.pilottery.pos.system.model.mm;

import java.io.Serializable;
import java.util.List;

public class MMInventoryCheck020507Req implements Serializable {
	private static final long serialVersionUID = -506098824924436973L;
	private List<MMInventoryCheckTag020507Req> tagList;
	public List<MMInventoryCheckTag020507Req> getTagList() {
		return tagList;
	}
	public void setTagList(List<MMInventoryCheckTag020507Req> tagList) {
		this.tagList = tagList;
	}
}
