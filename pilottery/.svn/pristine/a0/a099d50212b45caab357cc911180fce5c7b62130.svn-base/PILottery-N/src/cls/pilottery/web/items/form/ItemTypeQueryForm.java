package cls.pilottery.web.items.form;

import java.io.Serializable;

import cls.pilottery.common.model.BaseEntity;

public class ItemTypeQueryForm extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -3779105620776712229L;

    private String itemCodeQuery;
    private String itemNameQuery;
    
    public String getItemCodeQuery() {
        return itemCodeQuery;
    }
    
    public void setItemCodeQuery(String itemCodeQuery) {
        this.itemCodeQuery = itemCodeQuery == null ? null : itemCodeQuery.trim();
    }
    
    public String getItemNameQuery() {
        return itemNameQuery;
    }
    
    public void setItemNameQuery(String itemNameQuery) {
        this.itemNameQuery = itemNameQuery == null ? null : itemNameQuery.trim();
    }
}
