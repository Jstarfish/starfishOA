package cls.pilottery.web.checkTickets.model;

import java.util.Date;

public class CheckStatisticVo {
 private Date paidDay;
 private String paidOrg;
 private Long totalTickets;
 private Long totalAmount;
 private Long loveTickets;
 private Long loveAmount;
 private Long gongxiTickets;
 private Long gongxiAmount;
 private Long ballTickets;
 private Long ballAmount;
 private Long iphoneTickets;
 private Long iphoneAmount;
 private Long dglTickets;
 private Long dglAmount;
 private String orgName;
 private String operName;
 private String tickNo;
public Date getPaidDay() {
	return paidDay;
}
public void setPaidDay(Date paidDay) {
	this.paidDay = paidDay;
}
public String getPaidOrg() {
	return paidOrg;
}
public void setPaidOrg(String paidOrg) {
	this.paidOrg = paidOrg;
}
public Long getTotalTickets() {
	return totalTickets;
}
public void setTotalTickets(Long totalTickets) {
	this.totalTickets = totalTickets;
}
public Long getTotalAmount() {
	return totalAmount;
}
public void setTotalAmount(Long totalAmount) {
	this.totalAmount = totalAmount;
}
public Long getLoveTickets() {
	return loveTickets;
}
public void setLoveTickets(Long loveTickets) {
	this.loveTickets = loveTickets;
}
public Long getLoveAmount() {
	return loveAmount;
}
public void setLoveAmount(Long loveAmount) {
	this.loveAmount = loveAmount;
}
public Long getGongxiTickets() {
	return gongxiTickets;
}
public void setGongxiTickets(Long gongxiTickets) {
	this.gongxiTickets = gongxiTickets;
}
public Long getGongxiAmount() {
	return gongxiAmount;
}
public void setGongxiAmount(Long gongxiAmount) {
	this.gongxiAmount = gongxiAmount;
}
public Long getBallTickets() {
	return ballTickets;
}
public void setBallTickets(Long ballTickets) {
	this.ballTickets = ballTickets;
}
public Long getBallAmount() {
	return ballAmount;
}
public void setBallAmount(Long ballAmount) {
	this.ballAmount = ballAmount;
}
public Long getIphoneTickets() {
	return iphoneTickets;
}
public void setIphoneTickets(Long iphoneTickets) {
	this.iphoneTickets = iphoneTickets;
}
public Long getIphoneAmount() {
	return iphoneAmount;
}
public void setIphoneAmount(Long iphoneAmount) {
	this.iphoneAmount = iphoneAmount;
}
public Long getDglTickets() {
	return dglTickets;
}
public void setDglTickets(Long dglTickets) {
	this.dglTickets = dglTickets;
}
public Long getDglAmount() {
	return dglAmount;
}
public void setDglAmount(Long dglAmount) {
	this.dglAmount = dglAmount;
}
public String getOrgName() {
	return orgName;
}
public void setOrgName(String orgName) {
	this.orgName = orgName;
}
public String getOperName() {
	return operName;
}
public void setOperName(String operName) {
	this.operName = operName;
}
public String getTickNo() {
	return tickNo;
}
public void setTickNo(String tickNo) {
	this.tickNo = tickNo;
}
 
}
