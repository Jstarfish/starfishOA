package cls.pilottery.web.capital.service;

import cls.pilottery.web.capital.model.balancemodel.Balance;

public interface BalanceService {
	
	 public Balance getAccountBalanceInfo(String orgCode);
}
