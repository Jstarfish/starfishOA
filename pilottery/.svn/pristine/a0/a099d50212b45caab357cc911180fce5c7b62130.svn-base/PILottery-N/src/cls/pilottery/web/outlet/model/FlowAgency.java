package cls.pilottery.web.outlet.model;

import java.util.Date;


public class FlowAgency extends Agencys {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 807998061289043318L;

	private String agencyFundFlow;
	
	//当前最大流水用于查询返回分页条件
	private String maxFlow;

    private String refNo;

    //交易类型
    private Short flowType;
    
    //交易时间 
    private Date transTime;
    
    //站点余额 
    private long balance;
    
    //站点信用额度
    private long credit;
    
    //充值金额
    private long amount;
    
    //充值前金额
    private long beforeAmount;
    
    //充值后金额
    private long afterAmount;

	//市场管理员
    private int adminId;

	//密码
    private String password;

	//用于返回枚举的文本
    private String flowTypeText;

	private String accNo;
    
    private long changeAmount;
    
    private long frozenAmount;
    
    private long beAccountBalance;

    private long beFrozenBalance;

	private long afAccountBalance;

	private long afFrozenBalance;

	public String getAccNo() {
        return accNo;
    }

	public int getAdminId() {
		return adminId;
	}

    public long getAfAccountBalance() {
        return afAccountBalance;
    }

    public long getAfFrozenBalance() {
        return afFrozenBalance;
    }

    public long getAfterAmount() {
		return afterAmount;
	}

    public String getAgencyFundFlow() {
        return agencyFundFlow;
    }

    public long getAmount() {
		return amount;
	}

    public long getBalance() {
		return balance;
	}

    public long getBeAccountBalance() {
        return beAccountBalance;
    }

    public long getBeforeAmount() {
		return beforeAmount;
	}

    public long getBeFrozenBalance() {
        return beFrozenBalance;
    }

    public long getChangeAmount() {
        return changeAmount;
    }

    public long getCredit() {
		return credit;
	}

    public Short getFlowType() {
        return flowType;
    }

    public String getFlowTypeText() {
		return flowTypeText;
	}

    public long getFrozenAmount() {
        return frozenAmount;
    }

    public String getMaxFlow() {
		return maxFlow;
	}

    public String getPassword() {
		return password;
	}

    public String getRefNo() {
        return refNo;
    }

    public Date getTransTime() {
		return transTime;
	}

    public void setAccNo(String accNo) {
        this.accNo = accNo == null ? null : accNo.trim();
    }

    public void setAdminId(int adminId) {
		this.adminId = adminId;
	}

    public void setAfAccountBalance(long afAccountBalance) {
        this.afAccountBalance = afAccountBalance;
    }

    public void setAfFrozenBalance(long afFrozenBalance) {
        this.afFrozenBalance = afFrozenBalance;
    }

    public void setAfterAmount(long afterAmount) {
		this.afterAmount = afterAmount;
	}

    public void setAgencyFundFlow(String agencyFundFlow) {
        this.agencyFundFlow = agencyFundFlow == null ? null : agencyFundFlow.trim();
    }

    public void setAmount(long amount) {
		this.amount = amount;
	}

    public void setBalance(long balance) {
		this.balance = balance;
	}

	public void setBeAccountBalance(long beAccountBalance) {
        this.beAccountBalance = beAccountBalance;
    }

	public void setBeforeAmount(long beforeAmount) {
		this.beforeAmount = beforeAmount;
	}

	public void setBeFrozenBalance(long beFrozenBalance) {
        this.beFrozenBalance = beFrozenBalance;
    }

	public void setChangeAmount(long changeAmount) {
        this.changeAmount = changeAmount;
    }

	public void setCredit(long credit) {
		this.credit = credit;
	}

	public void setFlowType(Short flowType) {
        this.flowType = flowType;
    }

	public void setFlowTypeText(String flowTypeText) {
		this.flowTypeText = flowTypeText;
	}

	public void setFrozenAmount(long frozenAmount) {
        this.frozenAmount = frozenAmount;
    }

	public void setMaxFlow(String maxFlow) {
		this.maxFlow = maxFlow;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setRefNo(String refNo) {
        this.refNo = refNo == null ? null : refNo.trim();
    }

	public void setTransTime(Date transTime) {
		this.transTime = transTime;
	}
}