package cls.pilottery.web.checkTickets.model;

import java.io.Serializable;
import java.util.Date;

public class InquiryMain implements Serializable {

	private static final long serialVersionUID = 1L;

	private String payFlow;// 旧票兑奖序号

	private Date paidTime;// 兑奖时间

	private int paid_admin;// 兑奖人
	private String paidAdminName;

	private String paid_org;// 兑奖机构

	private long apply_tickets;// 提交票数

	private long succ_tickets;// 成功兑奖票数

	public InquiryMain() {

	}

	public long getApply_tickets() {

		return apply_tickets;
	}

	public int getPaid_admin() {

		return paid_admin;
	}

	public String getPaid_org() {

		return paid_org;
	}

	public Date getPaidTime() {

		return paidTime;
	}

	public String getPayFlow() {

		return payFlow;
	}

	public long getSucc_tickets() {

		return succ_tickets;
	}

	public void setApply_tickets(long apply_tickets) {

		this.apply_tickets = apply_tickets;
	}

	public void setPaid_admin(int paid_admin) {

		this.paid_admin = paid_admin;
	}

	public void setPaid_org(String paid_org) {

		this.paid_org = paid_org;
	}

	public void setPaidTime(Date paidTime) {

		this.paidTime = paidTime;
	}

	public void setPayFlow(String payFlow) {

		this.payFlow = payFlow;
	}

	public void setSucc_tickets(long succ_tickets) {

		this.succ_tickets = succ_tickets;
	}

	public String getPaidAdminName() {
		return paidAdminName;
	}

	public void setPaidAdminName(String paidAdminName) {
		this.paidAdminName = paidAdminName;
	}
}
