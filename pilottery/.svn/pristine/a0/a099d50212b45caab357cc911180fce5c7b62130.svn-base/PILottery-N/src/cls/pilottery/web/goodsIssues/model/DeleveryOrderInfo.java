package cls.pilottery.web.goodsIssues.model;

import java.io.Serializable;

public class DeleveryOrderInfo implements Serializable {
	private static final long serialVersionUID = 4642310875115663854L;
	private int applyAdmin;
	private String applyAdminName;
	private String orgCode;
	private String orgName;
	private String applyTime;
	public int getApplyAdmin() {
		return applyAdmin;
	}
	public void setApplyAdmin(int applyAdmin) {
		this.applyAdmin = applyAdmin;
	}
	public String getApplyAdminName() {
		return applyAdminName;
	}
	public void setApplyAdminName(String applyAdminName) {
		this.applyAdminName = applyAdminName;
	}
	public String getOrgCode() {
		return orgCode;
	}
	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getApplyTime() {
		return applyTime;
	}
	public void setApplyTime(String applyTime) {
		this.applyTime = applyTime;
	}
}
