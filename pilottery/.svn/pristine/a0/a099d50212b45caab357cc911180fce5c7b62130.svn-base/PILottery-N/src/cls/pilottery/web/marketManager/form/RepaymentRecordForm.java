package cls.pilottery.web.marketManager.form;

import cls.pilottery.common.model.BaseEntity;

public class RepaymentRecordForm extends BaseEntity {

	private static final long serialVersionUID = -1843494907640067450L;
	private String queryDate;
	private int currentUserId;

	public String getQueryDate() {
		return queryDate;
	}

	public void setQueryDate(String queryDate) {
		this.queryDate = queryDate;
	}

	public int getCurrentUserId() {
		return currentUserId;
	}

	public void setCurrentUserId(int currentUserId) {
		this.currentUserId = currentUserId;
	}
}
