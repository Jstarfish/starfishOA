package cls.pilottery.web.monitor.model;

import java.io.Serializable;

public class AreasInfo implements Serializable {
	private static final long serialVersionUID = 3144581667496615407L;
	private String areaName;
	private String areaCode;
	public String getAreaName() {
		return areaName;
	}
	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}
	public String getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}
}
