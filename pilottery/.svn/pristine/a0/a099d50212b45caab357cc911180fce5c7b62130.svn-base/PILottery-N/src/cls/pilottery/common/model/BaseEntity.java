package cls.pilottery.common.model;

import java.io.Serializable;

public class BaseEntity implements Serializable {
	private static final long serialVersionUID = 107647244048758615L;

	// 分页参数
	private Integer beginNum;

	private Integer endNum;

	// 调用sp返回的错误参数
	private Integer c_errcode;
	
	private String c_errmsg;

	public Integer getBeginNum() {
		return beginNum;
	}

	public void setBeginNum(Integer beginNum) {
		this.beginNum = beginNum;
	}

	public Integer getEndNum() {
		return endNum;
	}

	public void setEndNum(Integer endNum) {
		this.endNum = endNum;
	}

	public Integer getC_errcode() {
		return c_errcode;
	}

	public void setC_errcode(Integer cErrcode) {
		c_errcode = cErrcode;
	}

	public String getC_errmsg() {
		return c_errmsg;
	}

	public void setC_errmsg(String c_errmsg) {
		this.c_errmsg = c_errmsg;
	}
}
