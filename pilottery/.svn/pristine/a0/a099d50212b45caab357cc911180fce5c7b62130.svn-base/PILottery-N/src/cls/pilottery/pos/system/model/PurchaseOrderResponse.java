package cls.pilottery.pos.system.model;

import java.io.Serializable;
import java.util.List;

public class PurchaseOrderResponse implements Serializable {
	private static final long serialVersionUID = -7201669286981169579L;
	private String orderNo;
	private String time;
	private String status;
	private List<PurchaseOrderDetail> detailList;
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<PurchaseOrderDetail> getDetailList() {
		return detailList;
	}
	public void setDetailList(List<PurchaseOrderDetail> detailList) {
		this.detailList = detailList;
	}
}
