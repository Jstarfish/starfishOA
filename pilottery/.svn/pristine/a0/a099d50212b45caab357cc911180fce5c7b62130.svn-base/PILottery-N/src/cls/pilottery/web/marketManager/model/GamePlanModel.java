package cls.pilottery.web.marketManager.model;

public class GamePlanModel implements java.io.Serializable{
	private static final long serialVersionUID = 7631473633347367797L;
	private String planName;
	private String planCode;
	private String batchNo;
	private long amountEveryTruck;
	private long amountEveryBox;
	private long amountEveryPackage;
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPlanCode() {
		return planCode;
	}
	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}
	public String getBatchNo() {
		return batchNo;
	}
	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}
	public long getAmountEveryTruck() {
		return amountEveryTruck;
	}
	public void setAmountEveryTruck(long amountEveryTruck) {
		this.amountEveryTruck = amountEveryTruck;
	}
	public long getAmountEveryBox() {
		return amountEveryBox;
	}
	public void setAmountEveryBox(long amountEveryBox) {
		this.amountEveryBox = amountEveryBox;
	}
	public long getAmountEveryPackage() {
		return amountEveryPackage;
	}
	public void setAmountEveryPackage(long amountEveryPackage) {
		this.amountEveryPackage = amountEveryPackage;
	}
}
