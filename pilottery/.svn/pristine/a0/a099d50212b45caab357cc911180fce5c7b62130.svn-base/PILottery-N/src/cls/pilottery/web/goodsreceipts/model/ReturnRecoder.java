package cls.pilottery.web.goodsreceipts.model;

import java.util.Date;

public class ReturnRecoder {
    private String returnNo;

    private String agencyCode;

    private Short marketManagerAdmin;

    private Date applyDate;

    private Short warehouseManagerAdmin;

    private Date inboundDate;

    private Short financeAdmin;

    private Date approveDate;

    private Long packages;

    private Long amount;

    private Short status;

    private String approveRemark;
    private String realName;
    private String orgName;

    public String getReturnNo() {
        return returnNo;
    }

    public void setReturnNo(String returnNo) {
        this.returnNo = returnNo == null ? null : returnNo.trim();
    }

    public String getAgencyCode() {
        return agencyCode;
    }

    public void setAgencyCode(String agencyCode) {
        this.agencyCode = agencyCode == null ? null : agencyCode.trim();
    }

    public Short getMarketManagerAdmin() {
        return marketManagerAdmin;
    }

    public void setMarketManagerAdmin(Short marketManagerAdmin) {
        this.marketManagerAdmin = marketManagerAdmin;
    }

    public Date getApplyDate() {
        return applyDate;
    }

    public void setApplyDate(Date applyDate) {
        this.applyDate = applyDate;
    }

    public Short getWarehouseManagerAdmin() {
        return warehouseManagerAdmin;
    }

    public void setWarehouseManagerAdmin(Short warehouseManagerAdmin) {
        this.warehouseManagerAdmin = warehouseManagerAdmin;
    }

    public Date getInboundDate() {
        return inboundDate;
    }

    public void setInboundDate(Date inboundDate) {
        this.inboundDate = inboundDate;
    }

    public Short getFinanceAdmin() {
        return financeAdmin;
    }

    public void setFinanceAdmin(Short financeAdmin) {
        this.financeAdmin = financeAdmin;
    }

    public Date getApproveDate() {
        return approveDate;
    }

    public void setApproveDate(Date approveDate) {
        this.approveDate = approveDate;
    }

    public Long getPackages() {
        return packages;
    }

    public void setPackages(Long packages) {
        this.packages = packages;
    }

    public Long getAmount() {
        return amount;
    }

    public void setAmount(Long amount) {
        this.amount = amount;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(Short status) {
        this.status = status;
    }

    public String getApproveRemark() {
        return approveRemark;
    }

    public void setApproveRemark(String approveRemark) {
        this.approveRemark = approveRemark == null ? null : approveRemark.trim();
    }

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
    
}