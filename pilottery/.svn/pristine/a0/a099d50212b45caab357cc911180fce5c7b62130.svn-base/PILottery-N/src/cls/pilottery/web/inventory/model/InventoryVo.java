package cls.pilottery.web.inventory.model;

public class InventoryVo {
	private String planCode;
	private String planName;
	private String batchNo;
	private Long tickts;
	private Long amount;
	private Long  rewardGroup;

	public String getPlanCode() {
		return planCode;
	}

	public void setPlanCode(String planCode) {
		this.planCode = planCode;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	
	public Long getTickts() {
		return tickts;
	}

	public void setTickts(Long tickts) {
		this.tickts = tickts;
	}

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public Long getRewardGroup() {
		return rewardGroup;
	}

	public void setRewardGroup(Long rewardGroup) {
		this.rewardGroup = rewardGroup;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

}
