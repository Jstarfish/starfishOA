#include "../../rdpub/pub/fm_def.h"
#include "../../rdpub/pub/fm_sic_pub.h"
#include "../../ukey_include/fm_sic_cmd_def.h"
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#define SIC_SYMKEY_LEN 16
#define FM_SIC_FILE_MAXDIR 64
#define FM_SIC_FILE_MAXFILE 200

FM_HANDLE g_hDev = (FM_HANDLE)-1;

void PrintErro(FM_U32 u32Error)
{
	FM_U32 u32Len=128;
	FM_S8 as8Info[128]={0};
	printf("������Ϊ��%d\n",u32Error);
	FM_SIC_GetErrInfo(FM_LAN_EN,u32Error,&u32Len,as8Info);
	as8Info[u32Len]=0;
	printf("%s\n",as8Info);
}

void GetRadom()
{
	FM_U32 u32Error;
	FM_U8 lenbuf[20]={0};
	FM_U8 *buf;
	int i;
	FM_U32 radomlen=0;
	printf("input the lentgh��\n");
	scanf("%s",lenbuf);
	i=0;
	while(lenbuf[i])
	{
		radomlen*=10;
		radomlen+=(lenbuf[i]-'0');
		i++;
	}
	//printf("%d\n",radomlen);
	buf=malloc(radomlen);
	u32Error=FM_SIC_GenRandom(g_hDev,radomlen,buf);
    if (FME_OK != u32Error)
	{
		PrintErro(u32Error);
        return;
    }
	for(i=0;i<radomlen;i++)
	printf("0x%x,",buf[i]);
	printf("\n");
	free(buf);
}

void GetDeviceInfo()
{
	FM_U32 u32Error;
	FM_DEV_INFO stDevInfo;
	u32Error= FM_SIC_GetDeviceInfo(g_hDev,&stDevInfo);
	if (FME_OK != u32Error)
	{
		PrintErro(u32Error);
        return;
    }
	else
	{
		printf("���̣�%s\n",stDevInfo.au8IssuerName);
		printf("�ͺţ�%s\n",stDevInfo.au8DeviceName);

	}
}

void showmenu()
{
	printf("\n");
	printf("\n");
	printf("--------------------------------------\n");
	printf("0.open device\n");
    printf("1.user operate\n");
	printf("2.get random\n");
	printf("3.get device info\n");
    printf("4.SM1\n");
	printf("5.RSA\n");
    printf("6.SM2\n");
	printf("7.HASH�㷨\n");
	printf("8.file operate\n");
    printf("9.cert operate\n");
    printf("10.exit\n");
    printf("--------------------------------------\n");
}

void Userlog()
{
	FM_S8 as8Select[256] = {0};
	FM_U8 sbuf[30];
	FM_U8 newsbuf[30];
	FM_U32 u32Retry;
	FM_U32 u32Error;
	FM_U32 pinlen,newpinlen;
	while(1)
	{
		printf("\n");
        printf("\n");
        printf("\n");
		printf("1.user login\n");
		printf("2.admin login\n");
		printf("3.reset user password\n");
		printf("4.reset admin password\n");
		printf("5.logout\n");
		printf("6.return\n");

        scanf("%s", as8Select);

        if(strcmp(as8Select, "1") == 0)
        {
            printf("input password��\n");
			scanf("%s",sbuf);
			pinlen=strlen(sbuf);
			u32Error=FM_SIC_USER_Login(g_hDev,FM_PIN_OPER,sbuf,pinlen,0,&u32Retry);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
				printf("retry time��%d\n",u32Retry);
  			}
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "2") == 0)
        {
            printf("input password��\n");
			scanf("%s",sbuf);
			pinlen=strlen(sbuf);
			printf("%d\n",pinlen);
			u32Error=FM_SIC_USER_Login(g_hDev,FM_PIN_ADMIN,sbuf,pinlen,0,&u32Retry);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
				printf("retry time��%d\n",u32Retry);
            }
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "3") == 0)
        {
            printf("input password��\n");
			scanf("%s",sbuf);
			pinlen=strlen(sbuf);
			printf("%d\n",pinlen);

			printf("input new password��\n");
			scanf("%s",newsbuf);
			newpinlen=strlen(newsbuf);
			printf("%d\n",newpinlen);
			u32Error=FM_SIC_USER_ChangePin(g_hDev,FM_PIN_CHANGEOPER ,sbuf,pinlen,newsbuf,newpinlen,&u32Retry);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
				printf("retry times��%d\n",u32Retry);
			}
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "4") == 0)
        {
            printf("input password��\n");
			scanf("%s",sbuf);
			pinlen=strlen(sbuf);
			printf("%d\n",pinlen);

			printf("input new password��\n");
			scanf("%s",newsbuf);
			newpinlen=strlen(newsbuf);
			printf("%d\n",newpinlen);
			u32Error=FM_SIC_USER_ChangePin(g_hDev,FM_PIN_CHANGEADMIN,sbuf,pinlen,newsbuf,newpinlen,&u32Retry);

			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
				printf("retry times��%d\n",u32Retry);
			}
			else
            {
                printf("succeed\n");
            }

        }
        else if(strcmp(as8Select, "5") == 0)
        {
            u32Error=FM_SIC_USER_Logout(g_hDev,FM_HANDLE_INVALID);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
				printf("retry times��%d\n",u32Retry);
		    }
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "6") == 0)
        {
            return;
        }
	}
}

void Hash()
{
	FM_U8 filename[50];
	FM_U32 filehandle;
	FM_U32 u32Error;
	FM_U8 *filedata;

	struct stat buf;
	FM_U32 Maclen;
	FM_U8 au8OutMACbuf[20]={0};
	FM_U8 au8IV[20] =
	{
	    0x01,0x23,0x45,0x67,
	    0x89,0xab,0xcd,0xef,
	    0xfe,0xdc,0xba,0x98,
	    0x76,0x54,0x32,0x10,
	    0xf0,0xe1,0xd2,0xc3
	}; //�����ʼ������һ��̶�ֵ�����ܸı�

	printf("input the file path \n");
	scanf("%s",filename);
	filehandle=open(filename,O_RDONLY);

	if(filehandle<=0)
	{
		printf("open erro��\n");
		return;
	}
	u32Error=fstat(filehandle,&buf);
	filedata=malloc(buf.st_size);
	//printf("�ļ���С%d\n",buf.st_size);
	if(filedata<=0)
	{
		printf("erro��\n");
		free(filedata);
		close(filehandle);
		return;
	}
	u32Error=read(filehandle,filedata,buf.st_size);
	if(u32Error!=buf.st_size)
	{
		printf("erro��\n");
		free(filedata);
		close(filehandle);
		return;

	}
	close(filehandle);

	//HASH������ʼ��
    u32Error = FM_SIC_HashInit(g_hDev, FM_ALG_SHA1, au8IV, 20);
	if (FME_OK != u32Error)
	{
	    PrintErro(u32Error);
	    free(filedata);
	    return;
	}
	else
	{
		printf("succeed\n");
	}

    u32Error = FM_SIC_HashUpdate(g_hDev, FM_ALG_SHA1, filedata, buf.st_size);
		if (FME_OK != u32Error)
	{
		PrintErro(u32Error);
		free(filedata);
		return;
	}
	else
	{
		printf("succeed\n");
	}

    u32Error = FM_SIC_HashFinal(g_hDev, FM_ALG_SHA1, au8OutMACbuf, &Maclen);
		if (FME_OK != u32Error)
	{
		PrintErro(u32Error);
		free(filedata);
		return;
	}
	else
	{
		printf("succeed\n");
	}

	for(u32Error=0;u32Error<Maclen;u32Error++)
	printf("%d,",au8OutMACbuf[u32Error]);
	printf("\n");
	free(filedata);
}

void SM1()
{
	FM_U32 i;
	FM_S8 as8Select[256] = {0};
	FM_U8 keybuf[50];
	FM_U32 keyID;
	FM_U32 u32Error;
	FM_HKEY hkey;
	FM_U8 *filedata;
	FM_U8 *filedata2;
	FM_U32 Symdatalen;
	FM_U32 datalen;
	FM_U32 filehandle,filehandle2;
	struct stat buf;
	FM_U8 au8IV[SIC_SYMKEY_LEN] =
	{
        0xe8,0x3d,0x17,0x15,
		0xac,0xf3,0x48,0x63,
		0xac,0xeb,0x93,0xe0,
		0xe5,0xab,0x8b,0x90
	};
    FM_U32 u32IVLen = 16 ;
	while(1)
	{
		printf("\n");
		printf("\n");
		printf("\n");
		printf("1.generate key\n");
		printf("2.delect key\n");
		printf("3.Encrypt\n");
		printf("4.Decrypt\n");
		printf("5.return\n");
        scanf("%s",as8Select);
        if(strcmp(as8Select, "1") == 0)
        {
            printf("input key index");
            scanf("%d",&keyID);
			hkey=(FM_HKEY)(FM_U64)keyID;
			u32Error=FM_SIC_GenKey(g_hDev,FM_ALG_SM1,SIC_SYMKEY_LEN,(FM_HKEY*)&hkey,keybuf);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
  			    return;
			}
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "2") == 0)
        {
            printf("input key index");
            scanf("%d",&keyID);
			hkey=(FM_HKEY)(FM_U64)keyID;
			u32Error=FM_SIC_DelKey(g_hDev,hkey);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
  			    return;
			}
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "3") == 0)
        {
            printf("input key index");
            scanf("%d",&keyID);
			hkey=(FM_HKEY)(FM_U64)keyID;
			printf("input source file path\n");
			scanf("%s",keybuf);
			filehandle=open(keybuf,O_RDONLY);
			if(filehandle<=0)
			{
				printf("erro��\n");
				return;
			}
			u32Error=fstat(filehandle,&buf);
			if(buf.st_size % 16 == 0)
			{
                Symdatalen=buf.st_size;
            }
			else
			{
                Symdatalen=buf.st_size+(16-(buf.st_size%16));
            }
			filedata=malloc(Symdatalen);
			memset(filedata,0,Symdatalen);
			if(filedata<=0)
			{
				printf("erro��\n");
				close(filehandle);
				free(filedata);
				return;
			}
			u32Error=read(filehandle,filedata,buf.st_size);
			close(filehandle);
			if(u32Error!=buf.st_size)
			{
				printf("�ļ���ʧ�ܣ�\n");
				free(filedata);
				return;
			}

			printf("input dest file path\n");
			scanf("%s",keybuf);
			filedata2=malloc(Symdatalen);
			if(filedata2==NULL)
			{
				free(filedata);
				printf("�����ڴ�ʧ��\n");
				return;
			}
			filehandle2=open(keybuf,O_RDWR|O_TRUNC);
			u32Error=FM_SIC_Encrypt(g_hDev,hkey,FM_ALG_SM1,FM_ALGMODE_ECB,filedata,Symdatalen,filedata2,&datalen,NULL,0,au8IV,u32IVLen);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
				free(filedata);
  			    return;
			}
			else
			{
                printf("succeed\n");
            }

			for(i = 0; i < datalen; i++)
			{
                printf("%x,",filedata[i]);
            }
			printf("lentgh��%d\n",datalen);

			for(i = 0; i < datalen; i++)
			{
                printf("%x,",filedata2[i]);
            }

			free(filedata);
			write(filehandle2,filedata2,datalen);
			close(filehandle2);
        }
        else if(strcmp(as8Select, "4") == 0)
        {
            printf("input key index");
            scanf("%d",&keyID);
			hkey=(FM_HKEY)(FM_U64)keyID;
			printf("input source file path\n");
			scanf("%s",keybuf);
			filehandle=open(keybuf,O_RDONLY);
			if(filehandle<=0)
			{
				printf("�ļ���ʧ�ܣ�\n");
				return;
			}
			u32Error=fstat(filehandle,&buf);
			if(buf.st_size % 16 == 0)
			{
                Symdatalen=buf.st_size;
            }
			else
			{
                Symdatalen=buf.st_size+(16-(buf.st_size%16));
            }
			filedata=malloc(Symdatalen);
			memset(filedata,0,Symdatalen);
			if(filedata<=0)
			{
				printf("�ڴ�����ʧ�ܣ�\n");
				close(filehandle);
				free(filedata);
				return;
			}
			u32Error=read(filehandle,filedata,buf.st_size);
			close(filehandle);
			if(u32Error!=buf.st_size)
			{
				printf("�ļ���ʧ�ܣ�\n");
				free(filedata);
				return;
			}
			printf("input dest file path\n");
			scanf("%s",keybuf);
			filedata2=malloc(Symdatalen);
			if(filedata2==NULL)
			{
				free(filedata);
				printf("�����ڴ�ʧ��\n");
				return;
			}
			filehandle2=open(keybuf,O_RDWR|O_TRUNC);
			u32Error=FM_SIC_Decrypt(g_hDev,hkey,FM_ALG_SM1,FM_ALGMODE_ECB,filedata,Symdatalen,filedata2,&datalen,NULL,0,au8IV,u32IVLen);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
				free(filedata);
  			    return;
			}
			else
			{
                printf("succeed\n");
            }

			for(i = 0; i < datalen; i++)
			{
                printf("%x,",filedata[i]);
            }
			printf("lentgh��%d\n",datalen);

			for(i = 0; i < datalen; i++)
			{
                printf("%x,",filedata2[i]);
            }

			free(filedata);
			write(filehandle2,filedata2,datalen);
			close(filehandle2);
        }
        else if(strcmp(as8Select, "5") == 0)
        {
            return;
        }
	}
}

void RSA()
{
	FM_U32 i;
	FM_U32 Evalue=0;
	FM_S8 as8Select[256] = {0};
	FM_U8 keybuf[256];
	FM_U8 RSAOutbuf[512],RSAOutbuf2[512];
	FM_U32 keyID;
	FM_U32 u32Error;
	FM_U32 u32Inlen,u32RSALen;
	FM_HKEY hkey;
	FM_RSA_PublicKey Publickey;
	PFM_RSA_PublicKey pPbulickey=&Publickey;
	while(1)
	{
		printf("\n");
		printf("\n");
		printf("\n");
		printf("1.gen key pair\n");
		printf("2.delect key pair\n");
		printf("3.RSAEncrypt\n");
		printf("4.RSADecrypt\n");
		printf("5.return\n");
        scanf("%s", as8Select);
        if(strcmp(as8Select, "1") == 0)
        {
            printf("input key index");
            scanf("%d",&keyID);
			hkey=(FM_HKEY)(FM_U64)keyID;
			memset(pPbulickey,0,sizeof(FM_RSA_PublicKey));
			printf("input 'e' value");
			scanf("%s",keybuf);
			Evalue=0;
			i=0;
			while(keybuf[i])
			{
				Evalue*=10;
				Evalue+=(keybuf[i]-'0');
				i++;
			}
			((FM_U32*)(pPbulickey->e))[0]=Evalue;
			u32Error=FM_SIC_GenRSAKeypair(g_hDev,1024,&hkey,pPbulickey,NULL);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
            {
                printf("succeed��\n");
            }
        }
        else if(strcmp(as8Select, "2") == 0)
        {
            printf("input key index");
            scanf("%d",&keyID);
			hkey=(FM_HKEY)(FM_U64)keyID;
			u32Error=FM_SIC_DelRSAKeypair(g_hDev,hkey);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
                printf("succeed��\n");
            }

        }
        else if(strcmp(as8Select, "3") == 0)
        {
            printf("input key index");
            scanf("%d",&keyID);
			hkey=(FM_HKEY)(FM_U64)keyID;
			printf("input string\n");
			scanf("%s",keybuf);
			u32Inlen=strlen(keybuf);
			u32Error=FM_SIC_RSAEncrypt(g_hDev,hkey,keybuf,u32Inlen,RSAOutbuf,&u32RSALen,NULL);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
                printf("succeed��%d\n",u32RSALen);
            }

			RSAOutbuf[u32RSALen]=0;
			for(i = 0; i < u32RSALen; i++)
			{
                printf("0x%x,",RSAOutbuf[i]);
            }
        }
        else if(strcmp(as8Select, "4") == 0)
        {
            u32Error=FM_SIC_RSADecrypt(g_hDev,hkey,RSAOutbuf,u32RSALen,RSAOutbuf2,&u32Inlen,NULL);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
                printf("succeed��%d\n",u32Inlen);
            }
			RSAOutbuf2[u32Inlen]=0;
			printf("%s\n",RSAOutbuf2);
        }
        else if(strcmp(as8Select, "5") == 0)
        {
            return;
        }
	}
}

void SM2()
{
	FM_U32 i;
	FM_S8 as8Select[256] = {0};
	FM_U8 keybuf[256] = {0}, au8OutBuf[256] = {0};
	FM_U32 keyID;
	FM_U32 u32Error;
	FM_U32 u32Inlen, u32OutLen;
	FM_HKEY hkey;
	FM_ECC_PublicKey Publickey;
	PFM_ECC_PublicKey pstEccPubKey = &Publickey;
    FM_ECC_Cipher stEccCipher;
	while(1)
	{
		printf("\n");
		printf("\n");
		printf("\n");
		printf("1.gen key pair\n");
		printf("2.delect key pair\n");
		printf("3.SM2Encrypt\n");
		printf("4.SM2Decrypt\n");
        printf("5.SM2Exchange\n");
		printf("6.return\n");
        scanf("%s", as8Select);
        if(strcmp(as8Select, "1") == 0)
        {
            printf("input key index");
            scanf("%d",&keyID);
			hkey=(FM_HKEY)(FM_U64)keyID;
			memset(pstEccPubKey,0,sizeof(FM_ECC_PublicKey));
            u32Error = FM_SIC_GenECCKeypair(g_hDev, FM_ALG_SM2_1, &hkey, (PFM_ECC_PublicKey)pstEccPubKey, NULL);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
            {
                printf("succeed��\n");
            }
        }
        else if(strcmp(as8Select, "2") == 0)
        {
            printf("input key index");
            scanf("%d",&keyID);
			hkey=(FM_HKEY)(FM_U64)keyID;
            u32Error = FM_SIC_DelECCKeypair(g_hDev, hkey);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
                printf("succeed��\n");
            }

        }
        else if(strcmp(as8Select, "3") == 0)
        {
            printf("input key index");
            scanf("%d",&keyID);
			hkey=(FM_HKEY)(FM_U64)keyID;
			printf("input string\n");
			scanf("%s",keybuf);
			u32Inlen=strlen(keybuf);
            memset(&stEccCipher, 0, sizeof(FM_ECC_Cipher));
            u32Error = FM_SIC_ECCEncrypt(g_hDev, FM_ALG_SM2_1, hkey, keybuf, u32Inlen, NULL, &stEccCipher);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
                printf("succeed\n");
            }

            printf("x:");
			for(i = 0; i < 32; i++)
			{
                printf("0x%x,",stEccCipher.x[i]);
            }
            printf("\n");

            printf("y:");
			for(i = 0; i < 32; i++)
			{
                printf("0x%x,",stEccCipher.y[i]);
            }
            printf("\n");

            printf("C:");
			for(i = 0; i < stEccCipher.Clength; i++)
			{
                printf("0x%x,",stEccCipher.C[i]);
            }
            printf("\n");

            printf("M:");
			for(i = 0; i < 32; i++)
			{
                printf("0x%x,",stEccCipher.M[i]);
            }
            printf("\n");

        }
        else if(strcmp(as8Select, "4") == 0)
        {
            u32Error = FM_SIC_ECCDecrypt(g_hDev, FM_ALG_SM2_1, hkey, &stEccCipher, NULL, au8OutBuf, &u32OutLen);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
                printf("succeed��%d\n",u32Inlen);
            }
			au8OutBuf[u32OutLen]=0;
			printf("%s\n",au8OutBuf);
        }
        else if(strcmp(as8Select, "5") == 0)
        {

            FM_U32 u32Ret = 0;
            ECCGENAKEY stEccGenkey = {0};
            FM_HANDLE hGADWE = FM_NULL;
            FM_HKEY hKeyS = FM_NULL;
            FM_HKEY hKeyR = FM_NULL;

            stEccGenkey.u32SponsorIDLen = 3;
            memcpy(stEccGenkey.au8SponsorID, "123", 3);
            stEccGenkey.hSponsorKey = 0;

            stEccGenkey.u32ResponseIDLen = 4;
            memcpy(stEccGenkey.au8ResponseID, "4567", stEccGenkey.u32ResponseIDLen);
            stEccGenkey.hResponseKey = 1;

            stEccGenkey.u32Alg = FM_ALG_SM1;
            stEccGenkey.u32KeyBits = SIC_SYMKEY_LEN*8;

            u32Ret = FM_SIC_GenerateAgreementDataWithECC(g_hDev, stEccGenkey.u32Alg, (FM_HKEY)(FM_U64)stEccGenkey.hSponsorKey,
                stEccGenkey.u32KeyBits, stEccGenkey.au8SponsorID, stEccGenkey.u32SponsorIDLen,
                &stEccGenkey.stSponsorPubKey, &stEccGenkey.stSponsorTmpPubKey, &hGADWE);
            if (u32Ret!=FME_OK)
            {
                PrintErro(u32Ret);
            }

            u32Ret = FM_SIC_GenerateAgreementDataAndKeyWithECC(g_hDev, stEccGenkey.u32Alg, (FM_HKEY)(FM_U64)stEccGenkey.hResponseKey,
                stEccGenkey.u32KeyBits, stEccGenkey.au8ResponseID, stEccGenkey.u32ResponseIDLen,
                stEccGenkey.au8SponsorID, stEccGenkey.u32SponsorIDLen,
                &stEccGenkey.stSponsorPubKey, &stEccGenkey.stSponsorTmpPubKey,
                &stEccGenkey.stResponsePubKey, &stEccGenkey.stResponseTmpPubKey, &hKeyR);
            if (u32Ret!=FME_OK)
            {
                PrintErro(u32Ret);
            }

            u32Ret = FM_SIC_GenerateKeyWithECC(g_hDev, stEccGenkey.au8ResponseID, stEccGenkey.u32ResponseIDLen,
                &stEccGenkey.stResponsePubKey, &stEccGenkey.stResponseTmpPubKey, hGADWE, &hKeyS);
            if (u32Ret!=FME_OK)
            {
                PrintErro(u32Ret);
            }
            printf("succeed\n");
        }
        else if(strcmp(as8Select, "6") == 0)
        {
            return;
        }

	}
}

//���ļ�ϵͳ������ʾ����ʾ����Ŀ¼ʱ��Ҫ����ȫ��·������ʾ�����ļ�ʱֻ������Ŀ¼���ļ������ɡ�
void File()
{
	FM_S8 as8Select[256] = {0};
	FM_U8 keybuf[50] = {0};
	FM_U8 filebuf[2000] = {0};
	FM_U32 keyID;
	FM_S8 as8EnumDirName[FM_SIC_FILE_MAXDIR * (SIC_FILE_NAME_LEN + 1)] = {0};
	FM_S8 as8EnumDirName2[FM_SIC_FILE_MAXDIR * (SIC_FILE_NAME_LEN + 1)] = {0};
	FM_S8 as8EnumFileName[FM_SIC_FILE_MAXDIR * (SIC_FILE_NAME_LEN + 1)] = {0};
	FM_U32 u32Len;
	FM_U32 u32Error;
	FM_U32 i;

	while(1)
	{
		printf("\n");
		printf("\n");
		printf("\n");
        printf("0.fomat file system\n");
		printf("1.refresh  dir\n");
		printf("2.creat dir\n");
		printf("3.creat file\n");
		printf("4.delect dir\n");
		printf("5.delect file\n");
		printf("6.read file\n");
		printf("7.write file\n");
		printf("8.return\n");

		scanf("%s", as8Select);
        if(strcmp(as8Select, "0") == 0)
        {
            u32Error = FM_SIC_FILE_Init(g_hDev);
            if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}

			u32Error = FM_SIC_FILE_CreateDir(g_hDev, "\\root\\cert", 0);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "1") == 0)
        {
            printf("input dir name:");
			scanf("%s", as8EnumDirName);
			u32Len=FM_SIC_FILE_MAXDIR * (SIC_FILE_NAME_LEN + 1);
			u32Error = FM_SIC_FILE_EnmuDir(g_hDev, as8EnumDirName, &u32Len, as8EnumDirName2, NULL);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
				for(i=0;i<u32Len;i++)
				{
					if(as8EnumDirName2[i]==0)
					    printf("/ ");
					else
					    printf("%c",as8EnumDirName2[i]);
				}

			}

			u32Len=FM_SIC_FILE_MAXDIR * (SIC_FILE_NAME_LEN + 1);
			u32Error = FM_SIC_FILE_EnmuFile(g_hDev, as8EnumDirName, &u32Len, as8EnumFileName, NULL);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
				for(i=0;i<u32Len;i++)
				{
					if(as8EnumFileName[i]==0)
					    printf(" ");
					else
					    printf("%c",as8EnumFileName[i]);
				}
				printf("\n");
			}
            printf("succeed\n");
        }
        else if(strcmp(as8Select, "2") == 0)
        {
            printf("input dir name:");
			scanf("%s",as8EnumDirName);
			u32Error = FM_SIC_FILE_CreateDir(g_hDev, as8EnumDirName, 0);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
            {
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "3") == 0)
        {
            printf("input file name:");
			scanf("%s",as8EnumFileName);
			u32Error = FM_SIC_FILE_CreateFile(g_hDev, as8EnumDirName,as8EnumFileName,64, 0);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "4") == 0)
        {
            printf("input dir name:");
			scanf("%s",as8EnumDirName);
			u32Error = FM_SIC_FILE_DeleteDir(g_hDev, as8EnumDirName);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "5") == 0)
        {
            printf("input file name:");
			scanf("%s",as8EnumFileName);
			u32Error = FM_SIC_FILE_DeleteFile(g_hDev, as8EnumDirName,as8EnumFileName);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
		    }
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "6") == 0)
        {
            printf("input file name:");
			scanf("%s",as8EnumFileName);
			u32Error = FM_SIC_FILE_ReadFile(g_hDev, as8EnumDirName,as8EnumFileName,0,64,filebuf);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
				for(i=0;i<64;i++)
				{
					printf("0x%x,",filebuf[i]);
				}
				printf("\n");
			}
        }
        else if(strcmp(as8Select, "7") == 0)
        {
            printf("input file name:");
			scanf("%s",as8EnumFileName);
			printf("input string");
			scanf("%s",filebuf);
			u32Len=strlen(filebuf);
			u32Error = FM_SIC_FILE_WriteFile(g_hDev, as8EnumDirName,as8EnumFileName,0,u32Len,filebuf);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
		    }
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "8") == 0)
        {
           return;
        }
	}
}

void Cert()
{
	FM_S8 as8Select[256] = {0};
	FM_U8 filename[50];
	FM_U8 databuf[100];
	FM_U8 *filedata;
	FM_U32 keyID;
	FM_U32 u32Len;
	FM_U32 u32Error;
	FM_U32 filehandle;
	FM_U32 i;
	struct stat buf;
	while(1)
	{
		printf("\n");
		printf("\n");
		printf("\n");
		printf("1.write cert\n");
		printf("2.read cert info\n");
		printf("3.delect cert\n");
		printf("4.enum certs\n");
		printf("5.return\n");

        scanf("%s", as8Select);
        if(strcmp(as8Select, "1") == 0)
        {
            printf("input cert file path\n");
			scanf("%s",filename);
			printf("input Container name\n");
			scanf("%s",databuf);
			filehandle=open(filename,O_RDONLY);
			if(filehandle<=0)
			{
				printf("open file erro��\n");
				return;
			}
			printf("open file succeed��handle��%d\n",filehandle);
			u32Error=fstat(filehandle,&buf);
			filedata=malloc(buf.st_size);
			printf("file length%d\n",(int)buf.st_size);
			if(filedata<=0)
			{
				printf("malloc faile\n");
				free(filedata);
				close(filehandle);
				return;
			}
			u32Error=read(filehandle,filedata,buf.st_size);
			if(u32Error!=buf.st_size)
			{
				printf("�ļ���ʧ�ܣ�\n");
				free(filedata);
				close(filehandle);
				return;
			}

			close(filehandle);
			printf("start write cert\n");
			u32Error=FM_SIC_ContainerWrite(g_hDev,1,databuf,filedata,buf.st_size);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
                printf("succeed\n");
            }
			free(filedata);
        }
        else if(strcmp(as8Select, "2") == 0)
        {
            printf("input Container name\n");
            scanf("%s",databuf);
            u32Error=FM_SIC_ContainerRead(g_hDev,4, databuf,(FM_U8 *)&keyID,(FM_U32 *)&u32Len);
            if (FME_OK != u32Error)
            {
                PrintErro(u32Error);
            }
            else
            {
                printf("succeed��keyindex��%d\n",keyID);
            }
        }
        else if(strcmp(as8Select, "3") == 0)
        {
            printf("input Container name\n");
			scanf("%s",databuf);
			u32Error=FM_SIC_ContainerDelete(g_hDev,databuf);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
                printf("succeed\n");
            }
        }
        else if(strcmp(as8Select, "4") == 0)
        {
            u32Error=FM_SIC_ContainerEnum(g_hDev,databuf,&u32Len);
			if (FME_OK != u32Error)
			{
				PrintErro(u32Error);
			}
			else
			{
				printf(" succeed\n");
				for(i=0;i<u32Len;i++)
				{
					if(databuf[i]==0)
					printf(" ");
					else
					printf("%c",databuf[i]);
				}
				printf("\n");
			}
        }
        else if(strcmp(as8Select, "5") == 0)
        {
            return;
        }
	}
}

int main()
{
	FM_U32 u32Error;
	FM_U8 u8Index = 0;
	FM_U32 u32type = 4;
	FM_S8 as8Select[256] = {0};
	FM_S32 i=0;
	while(1)
	{
		showmenu();
        scanf("%s", as8Select);
        if(strcmp(as8Select, "0") == 0)
        {
            u32Error = FM_SIC_OpenDevice(&u8Index, FM_DEV_TYPE_SJK1150,
                (FM_OPEN_MULTITHREAD|FM_OPEN_MULTIPROCESS), &g_hDev);
		    if(u32Error != 0)
		    {
				PrintErro(u32Error);
			}
			else
			{
				printf("open device succeed");
			}
        }
        else if(strcmp(as8Select, "1") == 0)
        {
            Userlog();
        }
        else if(strcmp(as8Select, "2") == 0)
        {
            GetRadom();
        }
        else if(strcmp(as8Select, "3") == 0)
        {
            GetDeviceInfo();
        }
        else if(strcmp(as8Select, "4") == 0)
        {
            SM1();
        }
        else if(strcmp(as8Select, "5") == 0)
        {
            RSA();
        }
        else if(strcmp(as8Select, "6") == 0)
        {
            SM2();
        }
        else if(strcmp(as8Select, "7") == 0)
        {
            Hash();
        }
        else if(strcmp(as8Select, "8") == 0)
        {
            File();
        }
        else if(strcmp(as8Select, "9") == 0)
        {
            Cert();
        }
        else if(strcmp(as8Select, "10") == 0)
        {
            return 0;
        }
	}

	return 0;
}
